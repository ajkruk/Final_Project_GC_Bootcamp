// import { ObjectId } from 'mongodb';

interface TradeUser {
    
displayName: string,
email?: string
_id?: string,
profilePicture: string,
}

export default TradeUser