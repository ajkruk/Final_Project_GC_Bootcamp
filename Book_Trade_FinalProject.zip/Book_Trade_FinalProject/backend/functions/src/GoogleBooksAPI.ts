interface APIResponse {
    title: string;
    author: string;
    genre: string;
}

