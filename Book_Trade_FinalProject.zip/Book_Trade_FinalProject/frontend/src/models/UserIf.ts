interface UserIf {
    
    displayName: string,
    email?: string,
    _id?: string,
    profilePicture: string,
   }
   
   export default UserIf